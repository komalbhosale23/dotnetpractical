
using Microsoft.AspNetCore.Mvc;

namespace MvcPractical.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Message = "ASP.NET Core MVC Practical Example Running";
            return View();
        }
    }
}
