
import tkinter as tk
root = tk.Tk()
root.title("Draw Shapes")

canvas = tk.Canvas(root, width=400, height=400)
canvas.pack()

canvas.create_rectangle(50,50,150,150, fill="blue")
canvas.create_oval(200,50,300,150, fill="red")
canvas.create_line(50,200,350,200, width=3)

root.mainloop()
