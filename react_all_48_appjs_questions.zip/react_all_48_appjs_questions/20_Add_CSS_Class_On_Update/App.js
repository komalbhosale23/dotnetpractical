
import React,{useState} from "react";
export default function App(){
 const [active,setActive]=useState(false);
 return(
  <div className={active?"box active":"box"}>
   <button onClick={()=>setActive(!active)}>Toggle</button>
  </div>
 );
}
