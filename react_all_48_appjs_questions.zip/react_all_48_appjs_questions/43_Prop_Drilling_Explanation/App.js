
import React from "react";
export default function App(){
 return <h2>Prop drilling avoided using Context API</h2>;
}
