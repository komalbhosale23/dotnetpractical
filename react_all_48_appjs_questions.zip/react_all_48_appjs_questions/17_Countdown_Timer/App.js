
import React,{useState,useEffect} from "react";
export default function App(){
 const [time,setTime]=useState(10);
 useEffect(()=>{
  if(time>0){
   const t=setTimeout(()=>setTime(time-1),1000);
   return()=>clearTimeout(t);
  }
 },[time]);
 return <h2>Countdown: {time}</h2>;
}
