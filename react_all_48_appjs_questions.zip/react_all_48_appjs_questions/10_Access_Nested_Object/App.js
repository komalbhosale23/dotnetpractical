
import React from "react";
export default function App(){
 const user={name:"Komal",address:{city:"Mumbai"}};
 return <h2>{user.address.city}</h2>;
}
