
import tkinter as tk
from tkinter import messagebox

root = tk.Tk()

tk.Label(root,text="Name").grid(row=0,column=0)
entry = tk.Entry(root)
entry.grid(row=0,column=1)

def submit():
    if entry.get()=="":
        messagebox.showerror("Error","Enter Name")
    else:
        messagebox.showinfo("Success","Valid Input")

tk.Button(root,text="Submit",command=submit).grid(row=1,column=1)

root.mainloop()
