
import React,{useState} from "react";
export default function App(){
 const [user,setUser]=useState({name:"Komal",age:22});
 const update=()=>setUser({...user,age:23});
 return(
  <div>
   <h2>{user.name} {user.age}</h2>
   <button onClick={update}>Update Age</button>
  </div>
 );
}
