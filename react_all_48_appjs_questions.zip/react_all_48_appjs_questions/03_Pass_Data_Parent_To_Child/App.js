
import React from "react";
function Child({data}){
 return <h3>{data}</h3>;
}
export default function App(){
 return <Child data="Data sent from Parent Component"/>;
}
