
import tkinter as tk

root = tk.Tk()

menu = tk.Menu(root)
file = tk.Menu(menu,tearoff=0)

file.add_command(label="Open")
file.add_command(label="Save")

menu.add_cascade(label="File",menu=file)

root.config(menu=menu)

root.mainloop()
