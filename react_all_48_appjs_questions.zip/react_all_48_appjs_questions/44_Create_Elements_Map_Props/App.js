
import React from "react";
export default function App(){
 const list=["React","Node","Python"];
 return(
  <ul>
   {list.map((item,i)=><li key={i}>{item}</li>)}
  </ul>
 );
}
