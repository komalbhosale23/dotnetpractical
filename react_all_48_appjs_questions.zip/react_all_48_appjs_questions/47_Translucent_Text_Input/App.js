
import React from "react";
export default function App(){
 return(
  <input
   style={{background:"rgba(255,255,255,0.5)",padding:"10px"}}
   placeholder="Translucent Input"
  />
 );
}
