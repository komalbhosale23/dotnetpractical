
import React from "react";
export default function App(){
 return(
  <ul>
   <li>ReactJS: Web development</li>
   <li>React Native: Mobile app development</li>
  </ul>
 );
}
