
import React,{useState,useEffect} from "react";
export default function App(){
 const [color,setColor]=useState("transparent");

 useEffect(()=>{
  const change=()=>{
   if(window.scrollY>50) setColor("black");
   else setColor("transparent");
  };
  window.addEventListener("scroll",change);
 },[]);

 return <div style={{background:color,position:"fixed",width:"100%"}}>Navbar</div>;
}
