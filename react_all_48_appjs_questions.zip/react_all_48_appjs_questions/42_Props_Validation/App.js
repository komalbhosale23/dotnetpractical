
import React from "react";
import PropTypes from "prop-types";

function User({name}){
 return <h2>{name}</h2>;
}

User.propTypes={
 name:PropTypes.string
};

export default function App(){
 return <User name="Komal"/>;
}
