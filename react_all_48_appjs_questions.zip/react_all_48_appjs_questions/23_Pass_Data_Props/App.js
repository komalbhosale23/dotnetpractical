
import React from "react";
function Child({name}){
 return <h2>{name}</h2>;
}
export default function App(){
 return <Child name="React Props"/>;
}
