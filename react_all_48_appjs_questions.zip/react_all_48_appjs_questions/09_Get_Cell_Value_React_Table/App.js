
import React from "react";
export default function App(){
 const data=[{id:1,name:"React"},{id:2,name:"Node"}];
 return(
  <table border="1">
   <tbody>
    {data.map(row=>(
     <tr key={row.id}>
      <td onClick={()=>alert(row.name)}>{row.name}</td>
     </tr>
    ))}
   </tbody>
  </table>
 );
}
