
import React from "react";
export default function App(){
 const handle=(a,b)=>alert(a+" "+b);
 return <button onClick={()=>handle("Hello","React")}>Click</button>;
}
