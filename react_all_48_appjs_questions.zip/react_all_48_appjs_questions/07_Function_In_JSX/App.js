
import React from "react";
export default function App(){
 const greet=()=> "Hello ReactJS";
 return <h2>{greet()}</h2>;
}
