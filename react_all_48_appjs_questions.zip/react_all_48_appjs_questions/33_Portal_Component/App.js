
import React from "react";
export default function App(){
 return <h2>Portal Component Example</h2>;
}
