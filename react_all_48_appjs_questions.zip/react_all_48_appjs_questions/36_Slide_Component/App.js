
import React from "react";
export default function App(){
 return <h2>Slide Animation Example</h2>;
}
