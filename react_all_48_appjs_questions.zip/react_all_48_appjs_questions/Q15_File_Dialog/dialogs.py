
import tkinter as tk
from tkinter import filedialog

root = tk.Tk()

def openfile():
    filedialog.askopenfilename()

tk.Button(root,text="Open File",command=openfile).pack()

root.mainloop()
