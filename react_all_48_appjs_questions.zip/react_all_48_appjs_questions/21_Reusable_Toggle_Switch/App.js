
import React,{useState} from "react";
function Toggle(){
 const [on,setOn]=useState(false);
 return <button onClick={()=>setOn(!on)}>{on?"ON":"OFF"}</button>;
}
export default function App(){
 return <Toggle/>;
}
