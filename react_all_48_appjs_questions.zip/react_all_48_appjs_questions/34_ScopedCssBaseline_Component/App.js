
import React from "react";
export default function App(){
 return <h2>ScopedCssBaseline Example</h2>;
}
