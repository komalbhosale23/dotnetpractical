
import threading

lock = threading.Lock()

def task(name):
    for i in range(3):
        lock.acquire()
        print(name, "running", i)
        lock.release()

t1 = threading.Thread(target=task, args=("Thread1",))
t2 = threading.Thread(target=task, args=("Thread2",))

t1.start()
t2.start()
