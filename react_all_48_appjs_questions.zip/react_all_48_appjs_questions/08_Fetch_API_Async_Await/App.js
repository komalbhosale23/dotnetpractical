
import React,{useEffect,useState} from "react";
export default function App(){
 const [users,setUsers]=useState([]);
 useEffect(()=>{
  async function load(){
   const res=await fetch("https://jsonplaceholder.typicode.com/users");
   const data=await res.json();
   setUsers(data);
  }
  load();
 },[]);

 return(
  <ul>
   {users.map(u=><li key={u.id}>{u.name}</li>)}
  </ul>
 );
}
