
import React,{useState} from "react";
export default function App(){
 const [left,setLeft]=useState(0);
 return(
  <div>
   <div style={{position:"relative",left:left}}>Move Me</div>
   <button onClick={()=>setLeft(left+50)}>Move Right</button>
  </div>
 );
}
