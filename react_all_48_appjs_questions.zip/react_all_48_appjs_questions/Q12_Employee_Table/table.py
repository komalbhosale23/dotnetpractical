
import tkinter as tk
from tkinter import ttk

root = tk.Tk()

tree = ttk.Treeview(root,columns=("ID","Name"),show="headings")
tree.heading("ID",text="ID")
tree.heading("Name",text="Name")

tree.insert("",tk.END,values=(1,"John"))
tree.insert("",tk.END,values=(2,"Alice"))

tree.pack()

root.mainloop()
