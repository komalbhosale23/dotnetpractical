
import tkinter as tk

root = tk.Tk()
entry = tk.Entry(root,width=20)
entry.grid(row=0,columnspan=4)

def click(v):
    entry.insert(tk.END,v)

def calc():
    entry.insert(tk.END,"="+str(eval(entry.get())))

buttons=["1","2","3","+","4","5","6","-","7","8","9","*","0","/"]

row=1
col=0
for b in buttons:
    tk.Button(root,text=b,width=5,command=lambda x=b:click(x)).grid(row=row,column=col)
    col+=1
    if col>3:
        col=0
        row+=1

tk.Button(root,text="=",command=calc).grid(row=row,column=3)

root.mainloop()
