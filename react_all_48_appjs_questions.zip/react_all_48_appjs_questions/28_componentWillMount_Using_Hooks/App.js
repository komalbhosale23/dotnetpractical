
import React,{useEffect} from "react";
export default function App(){
 useEffect(()=>{
  console.log("Runs before render like componentWillMount");
 },[]);
 return <h2>Hook Equivalent</h2>;
}
