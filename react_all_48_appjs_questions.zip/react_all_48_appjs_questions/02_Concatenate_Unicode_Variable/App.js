
import React from "react";
export default function App(){
 const name="Komal";
 return <h2>{"\u2764 Hello " + name}</h2>;
}
