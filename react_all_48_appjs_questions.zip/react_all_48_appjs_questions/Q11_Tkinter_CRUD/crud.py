
import sqlite3

conn = sqlite3.connect("students.db")
c = conn.cursor()

c.execute("CREATE TABLE IF NOT EXISTS student(id INTEGER,name TEXT)")
conn.commit()

print("Database Ready")
