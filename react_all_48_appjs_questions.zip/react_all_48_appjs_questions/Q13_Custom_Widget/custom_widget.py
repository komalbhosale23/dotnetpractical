
import tkinter as tk

root = tk.Tk()

scale = tk.Scale(root,from_=0,to=100,orient="horizontal")
scale.pack()

root.mainloop()
