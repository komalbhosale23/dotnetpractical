
import React,{useState} from "react";
function Child({msg}){
 return <h2>{msg}</h2>;
}
export default function App(){
 const [msg,setMsg]=useState("");
 return(
  <div>
   <button onClick={()=>setMsg("Data Sent")}>Send</button>
   <Child msg={msg}/>
  </div>
 );
}
