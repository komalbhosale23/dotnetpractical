
import React, {useEffect, useState} from "react";
export default function App(){
 const [msg,setMsg]=useState("Loading...");
 useEffect(()=>{
   setMsg("useEffect executed after component mounted");
 },[]);
 return <h2>{msg}</h2>;
}
