
import React from "react";
export default function App(){
 const html="<h2>Hello from HTML String</h2>";
 return <div dangerouslySetInnerHTML={{__html:html}} />;
}
