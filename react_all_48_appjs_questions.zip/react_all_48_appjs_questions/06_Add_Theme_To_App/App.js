
import React from "react";
export default function App(){
 const theme={background:"#222",color:"white",padding:"20px"};
 return <div style={theme}><h2>Dark Theme Applied</h2></div>;
}
