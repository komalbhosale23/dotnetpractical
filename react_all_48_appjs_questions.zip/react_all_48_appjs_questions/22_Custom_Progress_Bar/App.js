
import React,{useState} from "react";
export default function App(){
 const [progress]=useState(60);
 return(
  <div style={{width:"200px",background:"#ddd"}}>
   <div style={{width:progress+"%",background:"green",height:"20px"}}></div>
  </div>
 );
}
