
import React,{useState} from "react";
export default function App(){
 const [open,setOpen]=useState(false);
 return(
  <div>
   <button onClick={()=>setOpen(!open)}>Toggle</button>
   {open && <h2>Collapsed Content</h2>}
  </div>
 );
}
