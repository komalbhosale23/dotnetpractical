
import React from "react";
export default function App(){
 return <h2>Material UI Navbar Example</h2>;
}
