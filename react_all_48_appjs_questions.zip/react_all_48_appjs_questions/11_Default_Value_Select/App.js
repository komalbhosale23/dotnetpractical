
import React,{useState} from "react";
export default function App(){
 const [course,setCourse]=useState("React");
 return(
  <select value={course} onChange={e=>setCourse(e.target.value)}>
   <option>React</option>
   <option>Angular</option>
  </select>
 );
}
