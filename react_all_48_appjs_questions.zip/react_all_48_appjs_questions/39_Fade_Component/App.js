
import React from "react";
export default function App(){
 return <h2>Fade Animation Example</h2>;
}
