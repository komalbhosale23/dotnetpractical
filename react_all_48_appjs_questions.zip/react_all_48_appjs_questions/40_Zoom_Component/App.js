
import React from "react";
export default function App(){
 return <h2>Zoom Animation Example</h2>;
}
