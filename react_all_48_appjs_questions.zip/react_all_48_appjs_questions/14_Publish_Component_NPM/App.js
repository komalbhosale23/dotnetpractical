
import React from "react";
export default function App(){
 return <h2>Component ready to publish on NPM</h2>;
}
