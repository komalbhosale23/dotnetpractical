
import React,{useState} from "react";
export default function App(){
 const [num,setNum]=useState("");
 return <input type="number" step="0.01" value={num} onChange={e=>setNum(e.target.value)}/>;
}
