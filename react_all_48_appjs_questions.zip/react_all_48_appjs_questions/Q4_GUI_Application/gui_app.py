
import tkinter as tk

def click():
    label.config(text="Button Clicked")

root = tk.Tk()
root.title("GUI App")

label = tk.Label(root, text="Hello Tkinter")
label.pack()

btn = tk.Button(root, text="Click Me", command=click)
btn.pack()

root.mainloop()
