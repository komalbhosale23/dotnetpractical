
using Microsoft.AspNetCore.Mvc;
using StudentManagementMVC.Models;
using System.Collections.Generic;
using System.Linq;

namespace StudentManagementMVC.Controllers
{
    public class StudentController : Controller
    {
        static List<Student> students = new List<Student>();

        public IActionResult Index()
        {
            return View(students);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Student s)
        {
            s.Id = students.Count + 1;
            students.Add(s);
            return RedirectToAction("Index");
        }

        public IActionResult Edit(int id)
        {
            var student = students.FirstOrDefault(x => x.Id == id);
            return View(student);
        }

        [HttpPost]
        public IActionResult Edit(Student s)
        {
            var student = students.FirstOrDefault(x => x.Id == s.Id);
            student.Name = s.Name;
            student.Age = s.Age;
            student.Course = s.Course;

            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var student = students.FirstOrDefault(x => x.Id == id);
            students.Remove(student);
            return RedirectToAction("Index");
        }
    }
}
