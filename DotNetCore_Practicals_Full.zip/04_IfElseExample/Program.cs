
using System;

namespace IfElseExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int number = 5;
            if (number > 0)
                Console.WriteLine("Positive Number");
            else
                Console.WriteLine("Negative Number");
            Console.ReadLine();
        }
    }
}
