
using System;

namespace SwitchCaseExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int day = 2;
            switch(day)
            {
                case 1: Console.WriteLine("Monday"); break;
                case 2: Console.WriteLine("Tuesday"); break;
                default: Console.WriteLine("Other Day"); break;
            }
            Console.ReadLine();
        }
    }
}
