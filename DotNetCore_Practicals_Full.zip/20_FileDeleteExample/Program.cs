
using System;
using System.IO;

class Program
{
    static void Main()
    {
        File.WriteAllText("temp.txt","Sample");
        File.Delete("temp.txt");
        Console.WriteLine("File Deleted");
        Console.ReadLine();
    }
}
