
using System;

namespace MethodParametersExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = Add(5,3);
            Console.WriteLine(result);
            Console.ReadLine();
        }
        static int Add(int a,int b)
        {
            return a+b;
        }
    }
}
