
using System;

namespace MethodOverloadingExample
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Add(2,3));
            Console.WriteLine(Add(2,3,4));
            Console.ReadLine();
        }
        static int Add(int a,int b)
        {
            return a+b;
        }
        static int Add(int a,int b,int c)
        {
            return a+b+c;
        }
    }
}
