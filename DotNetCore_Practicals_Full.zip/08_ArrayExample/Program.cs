
using System;

namespace ArrayExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = {1,2,3,4};
            foreach(int n in numbers)
                Console.WriteLine(n);
            Console.ReadLine();
        }
    }
}
