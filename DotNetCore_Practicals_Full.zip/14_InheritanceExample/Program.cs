
using System;

class Animal
{
    public void Speak()
    {
        Console.WriteLine("Animal Sound");
    }
}

class Dog : Animal
{
    public void Bark()
    {
        Console.WriteLine("Dog Bark");
    }
}

class Program
{
    static void Main()
    {
        Dog d = new Dog();
        d.Speak();
        d.Bark();
        Console.ReadLine();
    }
}
