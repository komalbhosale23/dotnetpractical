
using System;
using System.IO;

class Program
{
    static void Main()
    {
        using(StreamWriter sw = new StreamWriter("file.txt"))
        {
            sw.WriteLine("Hello World");
        }
        Console.WriteLine("File Written");
        Console.ReadLine();
    }
}
