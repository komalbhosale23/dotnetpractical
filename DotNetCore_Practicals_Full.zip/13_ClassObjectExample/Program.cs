
using System;

class Student
{
    public string Name;
    public void Display()
    {
        Console.WriteLine(Name);
    }
}

class Program
{
    static void Main()
    {
        Student s = new Student();
        s.Name = "Komal";
        s.Display();
        Console.ReadLine();
    }
}
