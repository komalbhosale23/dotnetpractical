
using System;

namespace MethodExample
{
    class Program
    {
        static void Main(string[] args)
        {
            ShowMessage();
            Console.ReadLine();
        }
        static void ShowMessage()
        {
            Console.WriteLine("Method Called");
        }
    }
}
