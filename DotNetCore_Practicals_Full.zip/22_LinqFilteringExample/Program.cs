
using System;
using System.Linq;

class Program
{
    static void Main()
    {
        int[] numbers = {1,2,3,4,5};
        var result = numbers.Where(n => n > 2);
        foreach(var n in result)
            Console.WriteLine(n);
        Console.ReadLine();
    }
}
