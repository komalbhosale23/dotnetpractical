
using System;

namespace ArraySortingExample
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = {5,2,8,1};
            Array.Sort(numbers);
            foreach(int n in numbers)
                Console.WriteLine(n);
            Console.ReadLine();
        }
    }
}
