
using System;

namespace StringInterpolationExample
{
    class Program
    {
        static void Main(string[] args)
        {
            string name = "Student";
            int age = 21;
            Console.WriteLine($"Name: {name}, Age: {age}");
            Console.ReadLine();
        }
    }
}
