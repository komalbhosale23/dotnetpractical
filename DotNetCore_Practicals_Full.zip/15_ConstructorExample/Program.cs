
using System;

class Person
{
    string name;
    public Person(string n)
    {
        name = n;
    }
    public void Show()
    {
        Console.WriteLine(name);
    }
}

class Program
{
    static void Main()
    {
        Person p = new Person("Komal");
        p.Show();
        Console.ReadLine();
    }
}
