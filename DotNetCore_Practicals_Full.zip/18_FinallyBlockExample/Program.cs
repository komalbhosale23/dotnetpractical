
using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.WriteLine("Try block executed");
        }
        finally
        {
            Console.WriteLine("Finally block executed");
        }
        Console.ReadLine();
    }
}
