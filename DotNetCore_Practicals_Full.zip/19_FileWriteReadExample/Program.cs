
using System;
using System.IO;

class Program
{
    static void Main()
    {
        File.WriteAllText("data.txt","Hello File");
        string text = File.ReadAllText("data.txt");
        Console.WriteLine(text);
        Console.ReadLine();
    }
}
