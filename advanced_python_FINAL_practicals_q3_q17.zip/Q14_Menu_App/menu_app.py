
import tkinter as tk
from tkinter import messagebox

def about():
 messagebox.showinfo("About","Menu Application")

root=tk.Tk()
menu=tk.Menu(root)

file=tk.Menu(menu,tearoff=0)
file.add_command(label="Exit",command=root.quit)

help=tk.Menu(menu,tearoff=0)
help.add_command(label="About",command=about)

menu.add_cascade(label="File",menu=file)
menu.add_cascade(label="Help",menu=help)

root.config(menu=menu)
root.mainloop()
