
import threading
import time

lock = threading.Lock()

def task(name):
    for i in range(5):
        lock.acquire()
        print(name,"running",i)
        time.sleep(1)
        lock.release()

t1 = threading.Thread(target=task,args=("Thread-1",))
t2 = threading.Thread(target=task,args=("Thread-2",))

t1.start()
t2.start()

t1.join()
t2.join()
