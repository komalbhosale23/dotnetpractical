
import tkinter as tk
from tkinter import ttk

root=tk.Tk()
tree=ttk.Treeview(root,columns=("ID","Name","Dept"),show="headings")

tree.heading("ID",text="ID")
tree.heading("Name",text="Name")
tree.heading("Dept",text="Dept")

tree.insert("",tk.END,values=(1,"John","HR"))
tree.insert("",tk.END,values=(2,"Alice","IT"))

tree.pack()

root.mainloop()
