
import tkinter as tk
from tkinter import messagebox

def submit():
    name = entry.get()
    if name == "":
        messagebox.showerror("Error","Please enter your name")
    else:
        messagebox.showinfo("Welcome",f"Hello {name}")

root = tk.Tk()
root.title("GUI Application")

tk.Label(root,text="Enter Name").pack()
entry = tk.Entry(root)
entry.pack()

tk.Button(root,text="Submit",command=submit).pack()

root.mainloop()
