
import tkinter as tk
from tkinter import filedialog

def open_file():
 file=filedialog.askopenfilename()
 print("Selected:",file)

root=tk.Tk()
tk.Button(root,text="Open File",command=open_file).pack()

root.mainloop()
