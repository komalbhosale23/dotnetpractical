
import sqlite3
import tkinter as tk

conn=sqlite3.connect("students.db")
cursor=conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS student(id INTEGER PRIMARY KEY,name TEXT)")

def add():
 cursor.execute("INSERT INTO student(name) VALUES(?)",(entry.get(),))
 conn.commit()

root=tk.Tk()
entry=tk.Entry(root)
entry.pack()

tk.Button(root,text="Add",command=add).pack()

root.mainloop()
