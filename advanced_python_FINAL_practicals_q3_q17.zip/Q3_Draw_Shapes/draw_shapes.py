
import tkinter as tk

root = tk.Tk()
root.title("Draw Shapes Example")

canvas = tk.Canvas(root,width=500,height=400,bg="white")
canvas.pack()

canvas.create_rectangle(50,50,200,150,fill="skyblue")
canvas.create_oval(250,50,400,150,fill="pink")
canvas.create_line(50,200,450,200,width=3)
canvas.create_polygon(200,250,250,300,150,300,fill="orange")

root.mainloop()
