
import tkinter as tk

def click(val):
 entry.insert(tk.END,val)

def calculate():
 try:
  result=eval(entry.get())
  entry.delete(0,tk.END)
  entry.insert(0,result)
 except:
  entry.insert(0,"Error")

root=tk.Tk()
root.title("Calculator")

entry=tk.Entry(root,width=20)
entry.grid(row=0,columnspan=4)

buttons=['7','8','9','+','4','5','6','-','1','2','3','*','0','/','=']

row=1
col=0
for b in buttons:
 cmd=calculate if b=='=' else lambda x=b:click(x)
 tk.Button(root,text=b,width=5,command=cmd).grid(row=row,column=col)
 col+=1
 if col>3:
  col=0
  row+=1

root.mainloop()
