
import tkinter as tk
from tkinter.ttk import Progressbar

root=tk.Tk()
root.title("Custom Widget")

progress=Progressbar(root,length=300,mode='determinate')
progress.pack()

def increase():
 progress['value']+=10

tk.Button(root,text="Increase",command=increase).pack()

root.mainloop()
